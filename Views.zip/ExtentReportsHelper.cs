﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using System.Reflection;
using System.IO;

namespace Selenium_IPM_Automation
{
    public static class ExtentReportsHelper
    {
        public static ExtentReports extent { get; set; }
        public static ExtentV3HtmlReporter reporter { get; set; }
        public static ExtentTest test { get; set; }
        static ExtentReportsHelper()
        {
            extent = new ExtentReports();
            //var file = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + "//ExtentReports//");
            //reporter = new ExtentV3HtmlReporter(Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "ExtentReports.html"));
            //reporter = new ExtentV3HtmlReporter(Path.Combine(System.Configuration.ConfigurationManager.AppSettings["ReportPath"], "ExtentReports.html"));
            reporter = new ExtentV3HtmlReporter(System.Configuration.ConfigurationManager.AppSettings["ReportPath"]);
            reporter.Config.DocumentTitle = "Automation Testing Report";
            reporter.Config.ReportName = "Regression Testing";
            reporter.Config.Theme = AventStack.ExtentReports.Reporter.Configuration.Theme.Standard;
            extent.AttachReporter(reporter);
            extent.AddSystemInfo("Application Under Test", "RMOPS_IPM_Testing");
            extent.AddSystemInfo("Environment", "QA");
            extent.AddSystemInfo("Machine", Environment.MachineName);
            extent.AddSystemInfo("OS", Environment.OSVersion.VersionString);
        }

        public static void  CreateTest(string testName)
        {
            test = extent.CreateTest(testName);
        }
        public static void SetStepStatusPass(string stepDescription)
        {
            test.Log(Status.Pass, stepDescription);            
        }
        public static void SetStepStatusWarning(string stepDescription)
        {
            test.Log(Status.Warning, stepDescription);
        }
        public static void SetTestStatusPass()
        {
            test.Pass("Test Executed Sucessfully!");
        }
        public static void SetTestStatusFailacrchived(string message = null)
        {
            var printMessage = "<p><b>Test FAILED!</b></p>";
            if (!string.IsNullOrEmpty(message))
            {
                printMessage += $"Message: <br>{message}<br>";
            }
            test.Fail(printMessage);
        }

        public static void SetTestStatusFail(string stacktrace)
        {
            var printMessage = stacktrace.ToString();
            if (!string.IsNullOrEmpty(printMessage))
            {
                test.Log(Status.Fail,printMessage);             
            }            
        }

        public static void SetTestStatusFailNew(string stacktrace,string path)
        {
            var printMessage = stacktrace.ToString();
            if (!string.IsNullOrEmpty(printMessage))
            {
                test.Log(Status.Fail, printMessage);
                test.Log(Status.Fail, "Error Path: " + test.AddScreenCaptureFromPath(path));
            }
        }

        public static void AddTestFailureScreenshot(string base64ScreenCapture)
        {
             test.AddScreenCaptureFromPath("Screenshot on Error:", base64ScreenCapture);
        }

        public static void SetTestStatusSkipped()
        {
            test.Skip("Test skipped!");
        }

        public static void flushreports() 
        {
            extent.Flush();
        }

    }
}
