﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using DocumentFormat.OpenXml;
using OfficeOpenXml;

namespace Selenium_IPM_Automation
{
    public static class ReadExcel
    {   
        public static List<T> ReadExcelToList<T>(this ExcelWorksheet worksheet) where T : new()
        {
            List<T> collection = new List<T>();
            try
            {
                DataTable dt = new DataTable();
                foreach (var firstRowCell in new T().GetType().GetProperties().ToList())
                {
                    //Add table colums with properties of T
                    dt.Columns.Add(firstRowCell.Name);
                }
                for (int rowNum = 2; rowNum <= worksheet.Dimension.End.Row; rowNum++)
                {
                    var wsRow = worksheet.Cells[rowNum, 1, rowNum, worksheet.Dimension.End.Column];

                    if (wsRow.Text!="") 
                    {
                        DataRow row = dt.Rows.Add();
                        foreach (var cell in wsRow)
                        {
                            row[cell.Start.Column - 1] = cell.Text;
                        }
                    }
                    
                    //DataRow row = dt.Rows.Add();
 
                    //foreach (var cell in wsRow)
                    //{
                    //    row[cell.Start.Column - 1] = cell.Text;
                    //}
                }

                //Get the colums of table
                var columnNames = dt.Columns.Cast<DataColumn>().Select(c => c.ColumnName).ToList();

                //Get the properties of T
                List<PropertyInfo> properties = new T().GetType().GetProperties().ToList();

                collection = dt.AsEnumerable().Select(row =>
                {
                    T item = Activator.CreateInstance<T>();
                    foreach (var pro in properties)
                    {
                        if (columnNames.Contains(pro.Name) || columnNames.Contains(pro.Name.ToUpper()))
                        {
                            PropertyInfo pI = item.GetType().GetProperty(pro.Name);
                            pro.SetValue(item, (row[pro.Name] == DBNull.Value) ? null : Convert.ChangeType(row[pro.Name], (Nullable.GetUnderlyingType(pI.PropertyType) == null) ? pI.PropertyType : Type.GetType(pI.PropertyType.GenericTypeArguments[0].FullName)));
                        }
                    }
                    return item;
                }).ToList();

            }
            catch (Exception ex)
            {
                //Save error log
            }

            return collection;
        }

        public static List<T> GetDataFromExcel<T>(int i,string Workbookname) where T : new()
        {
            //var file = new FileInfo(@"C:\Users\v-ppuranik\source\repos\Selenium_IPM_Automation\Selenium_IPM_Automation\TestData\AzureTestData.xlsx");
            //var file = new FileInfo("..\\TestData\\AzureTestData.xlsx");
            //var file = new FileInfo(@"C:\SeleniumScreenShots\AzureTestData.xlsx");           
            var file = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + "//TestData//"+ Workbookname);
            List<T> list = new List<T>();
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            if (file != null)
            {
                try
                {
                    using (ExcelPackage package = new ExcelPackage(file))
                    {
                        ExcelWorkbook workbook = package.Workbook;
                        if (workbook != null)
                        {
                            //ExcelWorksheet worksheet = workbook.Worksheets.FirstOrDefault();
                            //ExcelWorksheet worksheet = workbook.Worksheets.FirstOrDefault();
                            ExcelWorksheet worksheet = workbook.Worksheets[i];
                            if (worksheet != null)
                            {
                                list = worksheet.ReadExcelToList<T>();
                                //Your code
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    //Save error log
                }
            }
            return list;
        }
    }
}

