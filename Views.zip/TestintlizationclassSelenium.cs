﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Selenium_IPM_Automation;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Edge;

namespace Selenium_IPM_Automation
{
    public static class TestintlizationclassSelenium
    {
        public static string Dynamicurl = "https://irisipmtesting.crm10.dynamics.com/";

        //public static string Azurerurl = "http://rc.portal.azure.com/?feature.iriscore=true&l=EN.EN-US#home";

        public static void OpenBrowser(string Browsermode,string Azureurl)
        {
            killBrowser();
           if (Browsermode == "incognitochrome")
            {

                var cioptions = new ChromeOptions();
                cioptions.AddArgument(@"--start-maximized");
                cioptions.AddArgument(@"--disable-extensions");
                cioptions.AddArgument(@"--no-proxy-server");
                cioptions.AddArgument(@"--manual");
                cioptions.AddArgument(@"--SafeSites");
                cioptions.AddArgument(@"--incognito");               
                FrameWorkHelper.driver = new ChromeDriver("C:\\Users\\v-ppuranik\\source\\repos\\Selenium_IPM_Automation\\packages\\WebDriver.ChromeDriver.26.14.313457.1\\tools\\", cioptions);
                FrameWorkHelper.DeleteAllCookies();
                FrameWorkHelper.openurl(Dynamicurl);
            }

            else if (Browsermode == "chrome")
            {
                var coptions = new ChromeOptions();
                coptions.AddArgument(@"--start-maximized");
                coptions.AddArgument(@"--disable-extensions");
                coptions.AddArgument(@"--no-proxy-server");
                coptions.AddArgument(@"--manual");
                coptions.AddArgument(@"--SafeSites");
                FrameWorkHelper.driver = new ChromeDriver("C:\\Users\\v-ppuranik\\source\\repos\\Selenium_IPM_Automation\\packages\\WebDriver.ChromeDriver.26.14.313457.1\\tools\\",coptions);               
                FrameWorkHelper.DeleteAllCookies();
                FrameWorkHelper.openurl(Azureurl);
            }
            else if (Browsermode == "edge")
            {
                var options = new EdgeOptions();
                options.AddArgument(@"--start-maximized");
                options.AddArgument(@"--disable-extensions");
                options.AddArgument(@"--no-proxy-server");
                options.AddArgument(@"--manual");
                options.AddArgument(@"--SafeSites");
                FrameWorkHelper.driver = new EdgeDriver(@"C:\Users\v-ppuranik\source\repos\Selenium_IPM_Automation\packages\edgedriver_win32", options);
                FrameWorkHelper.DeleteAllCookies();
                FrameWorkHelper.openurl(Azureurl);
            }            
        }


        public static void killBrowser() 
        {
            //var chromeDriverProcesses = Process.GetProcessesByName("chrome");
            var chromeDriverProcesses = Process.GetProcessesByName("msedge");
            foreach (var chromeDriverProcess in chromeDriverProcesses)
            {
                chromeDriverProcess.Kill();
            }            
        }

        public static void CloseBrowser() 
        {
            FrameWorkHelper.driver.Quit();
        }
    }
}
