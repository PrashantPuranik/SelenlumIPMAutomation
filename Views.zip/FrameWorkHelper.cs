﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AventStack.ExtentReports;
using OpenQA.Selenium;
using OpenQA.Selenium.Support;
using OpenQA.Selenium.Support.UI;
using AventStack.ExtentReports.Reporter;
using System.Reflection;
using System.IO;

namespace Selenium_IPM_Automation
{
    public static class FrameWorkHelper
    {
        public static IWebDriver driver;

        public static void openurl(string url)
        {
            driver.Navigate().GoToUrl(url);
        }    
      
        public static void takescreenshot(string locale)
        {
            Screenshot ss = ((ITakesScreenshot)driver).GetScreenshot();
            //string path = String.Format(@"C:\SeleniumScreenShots\{0}_{1}_image.png", DateTime.Now.ToString("yyyyMMdd"), locale);
            var appsettingpath = System.Configuration.ConfigurationManager.AppSettings["SeleniumScreenShotPath"];
            string path = String.Format(appsettingpath, DateTime.Now.ToString("yyyyMMdd"), locale);
            ss.SaveAsFile(path,ScreenshotImageFormat.Png);
        }

        public static string returnstringpath() 
        {
            Random random = new Random();
            var rNum = random.Next(0,10000);
            Screenshot ss = ((ITakesScreenshot)driver).GetScreenshot();
            //string path = String.Format(@"C:\SeleniumScreenShots\{0}_{1}_image.png", DateTime.Now.ToString("yyyyMMdd"), locale);
            var appsettingpath = System.Configuration.ConfigurationManager.AppSettings["SeleniumScreenShotPath"];
            string path = String.Format(appsettingpath, DateTime.Now.ToString("yyyyMMdd"), rNum);
            ss.SaveAsFile(path, ScreenshotImageFormat.Png);
            return path;
        }

        public static void SetText(IWebElement element, string text)
        {
            try
            {
                element.SendKeys(text);
                ExtentReportsHelper.SetStepStatusPass("Text has been placed Successfully in textbox");
            }
            catch(Exception e)
            {
                ExtentReportsHelper.SetTestStatusFail(e.Message.ToString());
            }
        }

        public static void ClickElementById(string Id)
        {
            try
            {
                driver.FindElement(By.Id(Id)).Click();
                ExtentReportsHelper.SetStepStatusPass("Clicked on WebElement Successfully");                
            }
            catch (Exception e)
            {               
                ExtentReportsHelper.SetTestStatusFail(e.Message.ToString());
            }
        }

        public static void ClickElementByXpath(string xpath)
        {
            try
            {
                driver.FindElement(By.XPath(xpath)).Click();                
                ExtentReportsHelper.SetStepStatusPass("Clicked on WebElement Successfully");
            }
            catch (Exception e)
            {
               ExtentReportsHelper.SetTestStatusFail(e.Message.ToString());
            }
        }

        public static void CloseAllBrowser(string xpath)
        {
            driver.Quit();
        }

        public static IWebElement GetElement(string locator, string locatortype)
        {
            IWebElement element = null;
            try
            {
                switch (locatortype)
                {
                    case "Id":
                        element = driver.FindElement(By.Id(locator));
                        ExtentReportsHelper.SetStepStatusPass("Got WebElement Successfully using id Locator");
                        break;
                    case "Name":
                        element = driver.FindElement(By.Name(locator));                        
                        ExtentReportsHelper.SetStepStatusPass("Got WebElement Successfully using Name Locator");
                        break;
                    case "Xpath":
                        element = driver.FindElement(By.XPath(locator));
                        ExtentReportsHelper.SetStepStatusPass("Got WebElement Successfully using Xpath Locator");
                        break;
                    default:
                        break;
                }
            }
            catch(Exception e)
            {                
                ExtentReportsHelper.SetTestStatusFail(e.Message.ToString());
            }
            return element;
       }

        public static string GetText(IWebElement element) 
        {
            string elementtext = null;
            try
            {
                elementtext = element.Text;
                ExtentReportsHelper.SetStepStatusPass("Get the text from WebElement Successfully");              
            }
            catch (Exception e)
            {               
                ExtentReportsHelper.SetTestStatusFail(e.Message.ToString());
            }
            return elementtext;
        }

        public static void WaitunitilElementGetDisplayed(string xpath) 
        {
            try
            {
                new WebDriverWait(driver, TimeSpan.FromSeconds(8)).Until(driver => driver.FindElement(By.XPath(xpath)));
                ExtentReportsHelper.SetStepStatusPass("Element Displayed Successfully having locator is xpath");
            }
            catch (Exception e)
            {
                ExtentReportsHelper.SetTestStatusFailNew(e.Message.ToString(),returnstringpath());
                //ExtentReportsHelper.AddTestFailureScreenshot(returnstringpath());
                //ExtentReportsHelper.SetTestStatusFail(e.Message.ToString());
            }
        }

        public static void WaitunitilElementGetDisplayedById(string Id)
        {
            try
            {
                new WebDriverWait(driver, TimeSpan.FromSeconds(8)).Until(driver => driver.FindElement(By.Id(Id)));
                ExtentReportsHelper.SetStepStatusPass("Element Displayed Successfully having locator is Id");
            }
            catch (Exception e)
            {
                ExtentReportsHelper.SetTestStatusFail(e.Message.ToString());
            }

        }

        public static void DeleteAllCookies() 
        {
            driver.Manage().Cookies.DeleteAllCookies();
        }

        public static void RefreshScreen() 
        {
            driver.Navigate().Refresh();
        }

    }
}
