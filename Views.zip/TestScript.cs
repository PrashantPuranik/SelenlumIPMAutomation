﻿using NUnit.Framework;
using Selenium_IPM_Automation.TestDataObjects;
using System.Threading;


namespace Selenium_IPM_Automation
{
    public class TestScript
    {
        

        [TestCase()]
        public void Dynamics_IPM_Surface() 
        {
            Thread.Sleep(3000);
            Dynamics_TestViews.SetEmailAddress("irisadmin@SalesTIPtenant.onmicrosoft.com");
            Thread.Sleep(100);
            Dynamics_TestViews.ClickNextButton();
            Thread.Sleep(100);
            Dynamics_TestViews.SetPassword("Dyn@mics365!");
            Thread.Sleep(4000);
            Dynamics_TestViews.ClickSignInButton();
            Thread.Sleep(100);
            Dynamics_TestViews.ClickYesButton();
            string GetBizbartext = Dynamics_TestViews.GetBizbarContent();
            Assert.AreEqual("BizbarConetnts", GetBizbartext,"Excepted and Actual Bizbar Contents not matching");
            TestintlizationclassSelenium.CloseBrowser();
        }

        [TestCase()]
        public void Azure_IPM_Surface()
        {
            string WorkBookname = "AzureTestData.xlsx";
            var AzureData = ReadExcel.GetDataFromExcel<UsersTdo>(0, WorkBookname);
            foreach (var data in AzureData)
            {
                //var url = "http://rc.portal.azure.com/?feature.iriscore=true&l='" + data.LCID+ "'#home";               
                TestintlizationclassSelenium.OpenBrowser("edge",data.URL);
                ExtentReportsHelper.CreateTest(data.TestName);
                //Azure_TestView.SetEmailAddress("v-ppuranik@microsoft.com");
                //Thread.Sleep(1000);
                //Azure_TestView.ClickNextButton();
                Thread.Sleep(3000);
                //FrameWorkHelper.RefreshScreen();
                //Thread.Sleep(3000);
                Azure_TestView.ClickBellIcon();
                Thread.Sleep(4000);
                var status = Azure_TestView.VerifyLearnMoreButtonClicked(data.Label);
                Azure_TestView.VerifyLearnMoreButtonStatus(status);
                Azure_TestView.VerifyTextOnNotificationMessage(data.Description,data.Title);
                FrameWorkHelper.takescreenshot(data.Locale);
                TestintlizationclassSelenium.CloseBrowser();
                ExtentReportsHelper.flushreports();
            }

            //ExtentReportsHelper.flushreports();
        }

        [TestCase()]
        public void reporttest() 
        {         
            ExtentReportsHelper.CreateTest("CreateOwnTestforreport");
            ExtentReportsHelper.SetTestStatusPass();
            var testdetails = "Test Failed";
            ExtentReportsHelper.SetTestStatusFail(testdetails);
            ExtentReportsHelper.flushreports();
        }
    }
}
