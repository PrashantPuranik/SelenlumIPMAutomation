﻿using NUnit.Framework;
using System;

namespace Selenium_IPM_Automation
{
    class Azure_TestView
    {
        public static string notificationid = "__fxs_notification_0__";
        public static string BellIconXpath = "//*[@class='fxs-topbar-button' and @title='Notifications']";
        public static string NextButtonId = "idSIButton9";
        public static string BellIconTitleTextXpath = "//*[@class='fxs-blade-title-titleText msportalfx-tooltip-overflow']";
        public static string NotificationTitleTextXpath = "//*[@class='fxs-notificationmenu-notification-title-text msportalfx-tooltip-overflow']";

        public static void ClickNextButton()
        {
            FrameWorkHelper.ClickElementById(NextButtonId);
        }

        public static void SetEmailAddress(string UserName)
        {
            FrameWorkHelper.SetText(FrameWorkHelper.GetElement("//*[@type='email']", "Xpath"),UserName);
        }

        //public static void WaitforNotification() 
        //{
        //    int i = 0;
        //    while(i<3) 
        //     {
        //        FrameWorkHelper.RefreshScreen();
        //        i++;
        //     }
        //}

        public static void ClickBellIcon()
        {
            //WaitforNotification();
            FrameWorkHelper.WaitunitilElementGetDisplayed("//*[@class='fxs-toast-wrapper']");
            FrameWorkHelper.WaitunitilElementGetDisplayed("//div[@class='fxs-topbar-buttons-container fxs-topbar-search-activated-hidden']//div[@class='fxs-topbar-notifications']//a");
            FrameWorkHelper.ClickElementByXpath("//div[@class='fxs-topbar-buttons-container fxs-topbar-search-activated-hidden']//div[@class='fxs-topbar-notifications']//a");
        }

        public static bool VerifyLearnMoreButtonClicked(string Learnmoretext)
        {
            try
            {
                FrameWorkHelper.ClickElementByXpath("//*[@title='" + Learnmoretext + "' and @class='fxs-button fxt-button fxs-inner-solid-border fxs-portal-button-primary']");
                return true;
            }
            catch (Exception e)
            {
                ExtentReportsHelper.SetTestStatusFail(e.Message.ToString());
            }
            return false;
        }

        public static string GetNotificationDescriptionText()
        {
            FrameWorkHelper.WaitunitilElementGetDisplayedById(notificationid);
            string text = FrameWorkHelper.GetText(FrameWorkHelper.GetElement(notificationid, "Id"));            
            return text;
        }

        /*Commneted as Bell icon text we will not verify*/
        //public static string GetBellIconTitleText()
        //{
        //    FrameWorkHelper.WaitunitilElementGetDisplayed(BellIconTitleTextXpath);
        //    string text = FrameWorkHelper.GetText(FrameWorkHelper.GetElement(BellIconTitleTextXpath, "Xpath"));            
        //    return text;
        //}

        public static string GetNotificationTitleText()
        {
            FrameWorkHelper.WaitunitilElementGetDisplayed(NotificationTitleTextXpath);
            string text = FrameWorkHelper.GetText(FrameWorkHelper.GetElement(NotificationTitleTextXpath, "Xpath"));            
            return text;
        }

        public static void VerifyTextOnNotificationMessage(string NotificationDescriptionText,string NotficationTitleText)
        {
            try
            {
                Assert.AreEqual(GetNotificationDescriptionText(), NotificationDescriptionText, "Excepted and Actual Bizbar Contents are not matching");
                //Assert.AreEqual(GetBellIconTitleText(), BellIconNotificationText, "Excepted and Actual BellIconNotificationText are not matching");
                Assert.AreEqual(GetNotificationTitleText(), NotficationTitleText, "Excepted and Actual NotficationTitleText are not matching");
                ExtentReportsHelper.SetStepStatusPass("Excepted and Actual text are mateched on notification screen");
            }
            catch (Exception e)
            {
                //ExtentReportsHelper.SetTestStatusFail(e.Message.ToString());
                ExtentReportsHelper.SetTestStatusFailNew(e.Message.ToString(),FrameWorkHelper.returnstringpath());
            }
        }

        public static void VerifyLearnMoreButtonStatus(bool Buttonstatus)
        {
            Assert.IsTrue(Buttonstatus,"Learn More Button is clickable");
        }
    }
}
