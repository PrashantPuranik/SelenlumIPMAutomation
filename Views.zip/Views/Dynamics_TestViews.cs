﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Selenium_IPM_Automation
{
    static class Dynamics_TestViews
    {
        public static string EmailAddressXpath = "//*[@class='form-control ltr_override input ext-input text-box ext-text-box']";
        public static string NextButtonId = "idSIButton9";
        public static string MessageBarId = "notificationMessageAndButtons";
        public static string ExpandMessageBarId = "notificationExpandIcon";
        public static string CustomeIconXpath = "//*[@title='Dynamics 365 — custom']";

        public static void ClickNextButton()
        {         
            FrameWorkHelper.ClickElementById(NextButtonId);
        }

        public static void SetEmailAddress(string UserName)
        {
            
            FrameWorkHelper.SetText(FrameWorkHelper.GetElement("Xpath", "//*[@type='email']"),UserName);
        }

        public static void SetPassword(string Password)
        {            
            FrameWorkHelper.SetText(FrameWorkHelper.GetElement("Xpath", "//*[@type='password']"),Password);
        }

        public static string GetBizbarContent() 
        {          
            string bizbartext= FrameWorkHelper.GetText(FrameWorkHelper.GetElement("Id", "notificationMessageAndButtons"));
            return bizbartext;
        }

        public static void ExpandMessageBar() 
        {           
            FrameWorkHelper.ClickElementById(ExpandMessageBarId);
        }

        public static void ClickSignInButton()
        {           
            FrameWorkHelper.ClickElementById(NextButtonId);
        }

        public static void ClickYesButton() 
        {
            FrameWorkHelper.ClickElementById(NextButtonId);
        }

    }
}
